package es.clases;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "INICIO" );
        
        //pruebaContador();  
        //pruebaIncrementar();
        
        System.out.println( "FIN" );
    }
    
    public static void pruebaContador() {
    	StudentToolkit stk = new StudentToolkit();
    	
    //	System.out.println("Contador es inicial es: " +  stk.getContador());
    }
    
    public static void pruebaIncrementar() {
    	StudentToolkit stk = new StudentToolkit();
   /* 	stk.incrementar();
    	stk.incrementar(); */
    	// Debería ser 2
//    	System.out.println("Contador es: " +  stk.getContador());
    }
    /****************
     *##############
     *#  TODO      #
     *##############
     */
}
