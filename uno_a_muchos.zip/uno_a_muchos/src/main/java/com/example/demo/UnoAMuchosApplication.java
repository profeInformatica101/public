package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnoAMuchosApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnoAMuchosApplication.class, args);
	}

}
