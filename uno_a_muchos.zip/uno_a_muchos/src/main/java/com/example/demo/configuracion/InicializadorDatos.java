package com.example.demo.configuracion;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entidad.Autor;
import com.example.demo.entidad.Libro;
import com.example.demo.repositorio.AutorRepository;
import com.example.demo.repositorio.LibroRepository;
import com.github.javafaker.Faker;

@Component
public class InicializadorDatos implements CommandLineRunner  {
	 @Autowired
	    private AutorRepository autorRepository;

	    @Autowired
	    private LibroRepository libroRepository;

	@Override
	public void run(String... args) throws Exception {

		 Faker faker = new Faker();
	        List<Autor> autores = new ArrayList<>();

	        // Crear 10 autores
	        for (int i = 0; i < 10; i++) {
	            Autor autor = new Autor();
	            autor.setNombre(faker.name().fullName());
	            autores.add(autor);

	            // Para cada autor, crear de 1 a 3 libros
	            int numLibros = faker.number().numberBetween(1, 4);
	            for (int j = 0; j < numLibros; j++) {
	                Libro libro = new Libro();
	                libro.setTitulo(faker.book().title());
	                libro.setAutor(autor);
	                autor.getLibros().add(libro);
	            }
	        }

	        autorRepository.saveAll(autores);
	}

}
