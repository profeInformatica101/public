package com.example.demo.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entidad.Autor;
import com.example.demo.servicio.AutorService;

@Controller
@RequestMapping("/autores")
public class AutorController {

    @Autowired
    private AutorService autorService;

    @GetMapping
    public String listarAutores(Model model) {
       List<Autor> autores = autorService.listarTodos();
        model.addAttribute("autores", autores);
        return "autores/lista";
    }

    
}