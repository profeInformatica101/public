package com.example.demo.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entidad.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {
}