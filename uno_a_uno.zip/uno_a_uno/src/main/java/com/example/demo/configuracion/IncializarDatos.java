package com.example.demo.configuracion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entidad.CuentaUsuario;
import com.example.demo.entidad.Empleado;
import com.example.demo.servicio.EmpleadoService;
import com.github.javafaker.Faker;

@Component
public class IncializarDatos implements CommandLineRunner{
	@Autowired
	private EmpleadoService servicio;
	
	@Override
	public void run(String... args) throws Exception {
		 Faker faker = new Faker();

	        for (int i = 0; i < 10; i++) {
	            Empleado empleado = new Empleado();
	            
	            empleado.setNombre(faker.name().fullName());
	            CuentaUsuario cuenta = new CuentaUsuario();
	            cuenta.setUsername(faker.name().username());
	            cuenta.setPassword(faker.internet().password());
	            

	            empleado.setCuentaUsuario(cuenta);
	            cuenta.setEmpleado(empleado);

	            servicio.guardarEmpleado(empleado);
	        }
       

	}

}
