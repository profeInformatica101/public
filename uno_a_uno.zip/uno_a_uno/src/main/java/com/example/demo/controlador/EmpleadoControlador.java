package com.example.demo.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entidad.CuentaUsuario;
import com.example.demo.entidad.Empleado;
import com.example.demo.servicio.EmpleadoService;

@Controller
@RequestMapping("/empleados")
public class EmpleadoControlador {
	
	 @Autowired
	 private EmpleadoService empleadoService;

	  @GetMapping
	  public String listarEmpleados(Model model) {
	        model.addAttribute("empleados", empleadoService.listarTodos());
	        return "empleados/lista";
	    }

	    @GetMapping("/crear")
	    public String mostrarFormularioDeCrear(Model model) {
	        Empleado empleado = new Empleado();
	        empleado.setCuentaUsuario(new CuentaUsuario()); // Inicializar la cuenta de usuario
	        model.addAttribute("empleado", empleado);
	        return "empleados/formulario";
	    }

	    @PostMapping("/guardar")
	    public String guardarEmpleado(@ModelAttribute Empleado empleado) {
	        empleadoService.guardarEmpleado(empleado);
	        return "redirect:/empleados";
	    }

	
}
