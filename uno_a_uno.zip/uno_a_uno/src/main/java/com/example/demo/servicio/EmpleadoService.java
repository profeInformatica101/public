package com.example.demo.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entidad.CuentaUsuario;
import com.example.demo.entidad.Empleado;
import com.example.demo.repositorio.EmpleadoRepository;

@Service
public class EmpleadoService {

	@Autowired
	private EmpleadoRepository empleadoRepository;

	public Empleado crearEmpleadoConCuentaUsuario(Empleado empleado, CuentaUsuario cuentaUsuario) {
		empleado.setCuentaUsuario(cuentaUsuario);
		cuentaUsuario.setEmpleado(empleado);
		return empleadoRepository.save(empleado);
	}

	public List<Empleado> listarTodos() {
		return empleadoRepository.findAll();
	}

	public void guardarEmpleado(Empleado empleado) {
		empleadoRepository.save(empleado);
		
	}
}
